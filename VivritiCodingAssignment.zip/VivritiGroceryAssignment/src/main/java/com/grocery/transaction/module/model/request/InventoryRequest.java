package com.grocery.transaction.module.model.request;

import java.util.List;

public class InventoryRequest {
	
	private List<Long> itemId;

	public List<Long> getItemId() {
		return itemId;
	}

	public void setItemId(List<Long> itemId) {
		this.itemId = itemId;
	}
	
	
	

}
