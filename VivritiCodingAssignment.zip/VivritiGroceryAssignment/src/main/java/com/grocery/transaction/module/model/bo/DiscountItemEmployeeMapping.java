package com.grocery.transaction.module.model.bo;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;




@Entity
@Table(name = "DISCOUNT_EMPLOYEE_MAPPING")
public class DiscountItemEmployeeMapping {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "DISCOUNT_EMPLOYEE_MAPPING_ID", columnDefinition = "BIGINT(20)")
	private Long id;

	@Column(name = "DISCOUNT_ID")
	private Long discountId;

	@Column(name = "EMPLOYEE_ID")
	private Long employeeId;
	
	@Column(name = "ITEM_ID")
	private Long itemId;

	@Column(name = "CREATED_ON", nullable = false)
	private Date createdOn;

	@Column(name = "MODIFIED_ON", nullable = false)
	private Date modifiedOn;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Long getDiscountId() {
		return discountId;
	}

	public void setDiscountId(Long discountId) {
		this.discountId = discountId;
	}

	public Date getCreatedOn() {
		return createdOn;
	}

	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}

	public Date getModifiedOn() {
		return modifiedOn;
	}

	public void setModifiedOn(Date modifiedOn) {
		this.modifiedOn = modifiedOn;
	}

	public Long getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(Long employeeId) {
		this.employeeId = employeeId;
	}

	public Long getItemId() {
		return itemId;
	}

	public void setItemId(Long itemId) {
		this.itemId = itemId;
	}
	
	

}
