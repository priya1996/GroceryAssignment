package com.grocery.transaction.module.service.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.grocery.transaction.module.model.bo.DailyPurchase;
import com.grocery.transaction.module.model.bo.Discount;
import com.grocery.transaction.module.model.bo.DiscountItemEmployeeMapping;
import com.grocery.transaction.module.model.bo.Item;
import com.grocery.transaction.module.model.bo.Transaction;
import com.grocery.transaction.module.model.bo.TransactionItem;
import com.grocery.transaction.module.model.request.InventoryRequest;
import com.grocery.transaction.module.model.request.ItemRequest;
import com.grocery.transaction.module.model.request.SalesRequest;
import com.grocery.transaction.module.model.response.InventoryResponse;
import com.grocery.transaction.module.model.response.ItemResponse;
import com.grocery.transaction.module.model.response.ResultResponse;
import com.grocery.transaction.module.repository.DailyPurchaseRepository;
import com.grocery.transaction.module.repository.DiscountItemEmployeeMappingRepository;
import com.grocery.transaction.module.repository.DiscountRepository;
import com.grocery.transaction.module.repository.EmployeeRepository;
import com.grocery.transaction.module.repository.ItemRepository;
import com.grocery.transaction.module.repository.ProducerRepository;
import com.grocery.transaction.module.repository.TransactionItemRepository;
import com.grocery.transaction.module.repository.TransactionRepository;
import com.grocery.transaction.module.service.core.TransactionService;


@Service
public class TransactionServiceImpl implements TransactionService {


	@Autowired
	TransactionRepository transactionRepository;
	
	@Autowired
	TransactionItemRepository transactionItemRepository;
	
	@Autowired
	ItemRepository itemRepository;
	
	@Autowired
	ProducerRepository producerRepository;
	
	@Autowired
	DailyPurchaseRepository dailyPurchaseRepository;

	@Autowired
	DiscountRepository discountRepository;
	
	@Autowired
	EmployeeRepository employeeRepository;
	
	@Autowired
	DiscountItemEmployeeMappingRepository discountItemEmployeeMappingRepository;


	@Override
	@Transactional
	public ResultResponse buyItem(List<ItemRequest> itemRequestList)
	{
		// Null and Empty check for Request Object List
		if(itemRequestList.isEmpty() || itemRequestList == null) {
			ResultResponse response = new ResultResponse();
			response.setMsg("BadRequest");
			response.setCode("Error");
			return response;
		}
		
		List<ItemResponse> itemResponseList = new ArrayList<>();
		
		// collecting all itemIds to check stock existence
		List<Long> itemIds = itemRequestList.stream().map(x->x.getId()).collect(Collectors.toList());
		
		List<Item> items = itemRepository.findByIdList(itemIds);
		
		Transaction transaction = new Transaction();
		transaction.setCreatedOn(new Date());
		transaction.setModifiedOn(new Date());
		
		Double totalCost = 0D;
		
		for(ItemRequest request : itemRequestList) {
			
			List<Item> itemList = items.stream().filter(x->x.getId().equals(request.getId())).map(x->x).collect(Collectors.toList());
			if(!itemList.isEmpty() && itemList != null) {
				
				Item item = itemList.get(0);
				List<DailyPurchase> dpList = dailyPurchaseRepository.findByItemId(request.getId());

				if(item.getExpiryDate().after(new Date()) && ((dpList.isEmpty() && request.getQuantity() < item.getQuantity()) || (dpList == null && request.getQuantity() < item.getQuantity()) || dpList.get(0).getQuantityLeft()>request.getQuantity())) {
					
					
						DailyPurchase dp = new DailyPurchase();
						dp.setCreatedOn(new Date());
						dp.setDate(new Date());
						dp.setItemId(request.getId());
						dp.setModifiedOn(new Date());
						dp.setQuantityLeft(dpList.isEmpty() ? item.getQuantity() - request.getQuantity() : 
							dpList.get(0).getQuantityLeft() - request.getQuantity());
						dp.setSalesCost(request.getQuantity()*item.getPrice());
						
						totalCost += dp.getSalesCost();
						
						
						TransactionItem transactionItem = new TransactionItem();
						transactionItem.setCreatedOn(new Date());
						transactionItem.setItemId(request.getId());
						transactionItem.setModifiedOn(new Date());
						transactionItem.setTransactionId(transaction.getId());
						
						dailyPurchaseRepository.save(dp);
						transactionItemRepository.save(transactionItem);
						
						ItemResponse itemResponse = new ItemResponse();
						itemResponse.setCost(dp.getSalesCost());
						itemResponse.setItemId(item.getId());
						itemResponse.setItemName(item.getName());
						itemResponse.setQuantitySold(request.getQuantity());
						
						itemResponseList.add(itemResponse);
					
				}
				
			}
		}
		
		transaction.setTotalCost(totalCost);
		transactionRepository.save(transaction);
		
		ResultResponse resultResponse = new ResultResponse();
		resultResponse.setBillId(transaction.getId());
		resultResponse.setTotalBillCost(totalCost);
		resultResponse.setItemResponseList(itemResponseList);
		resultResponse.setCode("200");
		resultResponse.setMsg("success");
		
		return resultResponse;
	}

	@Override
	@Transactional
	public List<InventoryResponse> printInventory(InventoryRequest request)
	{
		List<Item> itemList = null;
		List<InventoryResponse> inventoryResponseList = new ArrayList<>();
		if(request == null || request.getItemId().isEmpty() || request.getItemId() == null) {
			itemList = itemRepository.findAll();
		}
		else {
			itemList = itemRepository.findByIdList(request.getItemId());
		}
		
		for(Item item : itemList) {
			
			InventoryResponse ir = new InventoryResponse();
			ir.setDate(new Date());
			ir.setItemId(item.getId());
			ir.setItemName(item.getName());
			
			List<DailyPurchase> dpList = dailyPurchaseRepository.findByItemId(item.getId());

			ir.setQuantityLeft(dpList.get(0).getQuantityLeft());
			ir.setQuantitySold(item.getQuantity() - dpList.get(0).getQuantityLeft());
			
			inventoryResponseList.add(ir);
			
		}
		
		return inventoryResponseList;
	}

	@Override
	@Transactional
	public ResultResponse getTotalSales(SalesRequest request)
	{
		ResultResponse response = new ResultResponse();
		List<ItemResponse> itemResponseList = new ArrayList<>();
		List<Item> itemList = new ArrayList<>();
		if(request.getDate() == null && (request.getItemId().isEmpty() || request.getItemId() == null)) {
			 itemList = itemRepository.findAll();
		}
		else if(request.getDate() == null && (!request.getItemId().isEmpty() || request.getItemId() != null)) {
			itemList = 	itemRepository.findByIdList(request.getItemId());
		}
		else {
			List<Long> itemIdList = dailyPurchaseRepository.getDailyPurchaseByDate(request.getDate());
			itemList = itemRepository.findByIdList(itemIdList);
		}
		
		for(Item item : itemList) {
			
			ItemResponse itemResponse = new ItemResponse();
			itemResponse.setItemId(item.getId());
			itemResponse.setItemName(item.getName());
			itemResponse.setDate(request.getDate());
			List<DailyPurchase> dpList = dailyPurchaseRepository.findByItemId(item.getId());

			itemResponse.setQuantityLeft(dpList.get(0).getQuantityLeft());
			itemResponse.setQuantitySold(item.getQuantity() - dpList.get(0).getQuantityLeft());
			
			itemResponseList.add(itemResponse);
		}
		response.setItemResponseList(itemResponseList);
		
		return response;
	}

	@Override
	@Transactional
	public ResultResponse applyDiscountForEmployee(Long empId, List<ItemRequest> itemRequestList)
	{
		List<DiscountItemEmployeeMapping> discountList = discountItemEmployeeMappingRepository.findByEmpId(empId);
		
		List<Long> itemIds = itemRequestList.stream().map(x->x.getId()).collect(Collectors.toList());
		
		List<Item> items = itemRepository.findByIdList(itemIds);
		
		Transaction transaction = new Transaction();
		transaction.setCreatedOn(new Date());
		transaction.setModifiedOn(new Date());
		
		Double totalCost = 0D;
		
		List<ItemResponse> itemResponseList = new ArrayList<>();
		
		for(ItemRequest request : itemRequestList) {
			
			List<DiscountItemEmployeeMapping> dis = discountList.stream().filter(x->x.getItemId().equals(
					request.getId())).map(x->x).collect(Collectors.toList());
			
			if(dis != null && !dis.isEmpty()) {
				
				List<Item> itemList = items.stream().filter(x->x.getId().equals(request.getId())).map(x->x).collect(Collectors.toList());
					
				Item item = itemList.get(0);
				List<DailyPurchase> dpList = dailyPurchaseRepository.findByItemId(request.getId());

				
				Optional<Discount> discount = discountRepository.findById(dis.get(0).getDiscountId());
				DailyPurchase dp = new DailyPurchase();
				dp.setCreatedOn(new Date());
				dp.setDate(new Date());
				dp.setItemId(request.getId());
				dp.setModifiedOn(new Date());
				dp.setQuantityLeft(dpList.isEmpty() ? item.getQuantity() - request.getQuantity() : 
					dpList.get(0).getQuantityLeft() - request.getQuantity());
				
				Double cost = item.getPrice() - (item.getPrice() * discount.get().getPercent()/100);
				
				dp.setSalesCost(request.getQuantity()*cost);
				
				totalCost += dp.getSalesCost();
				
				
				TransactionItem transactionItem = new TransactionItem();
				transactionItem.setCreatedOn(new Date());
				transactionItem.setItemId(request.getId());
				transactionItem.setModifiedOn(new Date());
				transactionItem.setTransactionId(transaction.getId());
				
				dailyPurchaseRepository.save(dp);
				transactionItemRepository.save(transactionItem);
				
				ItemResponse itemResponse = new ItemResponse();
				itemResponse.setCost(dp.getSalesCost());
				itemResponse.setItemId(item.getId());
				itemResponse.setItemName(item.getName());
				itemResponse.setQuantitySold(request.getQuantity());
				
				itemResponseList.add(itemResponse);
			}
			
		}
		
		transaction.setTotalCost(totalCost);
		transactionRepository.save(transaction);
		
		ResultResponse resultResponse = new ResultResponse();
		resultResponse.setBillId(transaction.getId());
		resultResponse.setTotalBillCost(totalCost);
		resultResponse.setItemResponseList(itemResponseList);
		resultResponse.setCode("200");
		resultResponse.setMsg("success");
		
		return resultResponse;
		
	}

	@Override
	@Transactional
	public ResultResponse applyDiscountForCustomer(List<ItemRequest> itemRequestList)
	{
		
		List<Long> itemIds = itemRequestList.stream().map(x->x.getId()).collect(Collectors.toList());
		
		List<Item> items = itemRepository.findByIdList(itemIds);
		
		Transaction transaction = new Transaction();
		transaction.setCreatedOn(new Date());
		transaction.setModifiedOn(new Date());
		
		Double totalCost = 0D;
		
		List<ItemResponse> itemResponseList = new ArrayList<>();
		
		for(ItemRequest request : itemRequestList) {
			
			List<DiscountItemEmployeeMapping> dis = discountItemEmployeeMappingRepository.findByItemId(request.getId());

			
			if(dis != null && !dis.isEmpty()) {
				
				List<Item> itemList = items.stream().filter(x->x.getId().equals(request.getId())).map(x->x).collect(Collectors.toList());
					
				Item item = itemList.get(0);
				List<DailyPurchase> dpList = dailyPurchaseRepository.findByItemId(request.getId());

				
				Optional<Discount> discount = discountRepository.findById(dis.get(0).getDiscountId());
				DailyPurchase dp = new DailyPurchase();
				dp.setCreatedOn(new Date());
				dp.setDate(new Date());
				dp.setItemId(request.getId());
				dp.setModifiedOn(new Date());
				dp.setQuantityLeft(dpList.isEmpty() ? item.getQuantity() - request.getQuantity() : 
					dpList.get(0).getQuantityLeft() - request.getQuantity());
				
				Double cost = item.getPrice() - (item.getPrice() * discount.get().getPercent()/100);
				
				dp.setSalesCost(request.getQuantity()*cost);
				
				totalCost += dp.getSalesCost();
				
				
				TransactionItem transactionItem = new TransactionItem();
				transactionItem.setCreatedOn(new Date());
				transactionItem.setItemId(request.getId());
				transactionItem.setModifiedOn(new Date());
				transactionItem.setTransactionId(transaction.getId());
				
				dailyPurchaseRepository.save(dp);
				transactionItemRepository.save(transactionItem);
				
				ItemResponse itemResponse = new ItemResponse();
				itemResponse.setCost(dp.getSalesCost());
				itemResponse.setItemId(item.getId());
				itemResponse.setItemName(item.getName());
				itemResponse.setQuantitySold(request.getQuantity());
				
				itemResponseList.add(itemResponse);
			}
			
		}
		
		transaction.setTotalCost(totalCost);
		transactionRepository.save(transaction);
		
		ResultResponse resultResponse = new ResultResponse();
		resultResponse.setBillId(transaction.getId());
		resultResponse.setTotalBillCost(totalCost);
		resultResponse.setItemResponseList(itemResponseList);
		resultResponse.setCode("200");
		resultResponse.setMsg("success");
		
		return resultResponse;
	}
}
