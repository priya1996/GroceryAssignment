package com.grocery.transaction.module.model.bo;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;




@Entity
@Table(name = "DAILYPURCHASE")
public class DailyPurchase {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "DAILYPURCHASE_ID", columnDefinition = "BIGINT(20)")
	private Long id;

	@Column(name = "QUANTITYLEFT")
	private Long quantityLeft;

	@Column(name = "DATE", nullable = false)
	private Date date;

	@Column(name = "ITEM_ID")
	private Long itemId;

	@Column(name = "SALES")
	private Double salesCost;

	@Column(name = "CREATED_ON", nullable = false)
	private Date createdOn;

	@Column(name = "MODIFIED_ON", nullable = false)
	private Date modifiedOn;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Long getItemId() {
		return itemId;
	}

	public void setItemId(Long itemId) {
		this.itemId = itemId;
	}

	public Long getQuantityLeft() {
		return quantityLeft;
	}

	public void setQuantityLeft(Long quantityLeft) {
		this.quantityLeft = quantityLeft;
	}


	public Double getSalesCost() {
		return salesCost;
	}

	public void setSalesCost(Double salesCost) {
		this.salesCost = salesCost;
	}

	public Date getCreatedOn() {
		return createdOn;
	}

	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}

	public Date getModifiedOn() {
		return modifiedOn;
	}

	public void setModifiedOn(Date modifiedOn) {
		this.modifiedOn = modifiedOn;
	}

	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}

}
