package com.grocery.transaction.module.repository;

import java.io.Serializable;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.transaction.annotation.Transactional;

import com.grocery.transaction.module.model.bo.TransactionItem;

@Transactional
public interface TransactionItemRepository extends JpaRepository<TransactionItem, Serializable> {

}
