package com.grocery.transaction.module.repository;

import java.io.Serializable;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import com.grocery.transaction.module.model.bo.Item;

@Transactional
public interface ItemRepository extends JpaRepository<Item, Serializable> {
	
	@Query(" SELECT * FROM Item WHERE id IN (:ids) ")
	List<Item> findByIdList(@Param("ids")List<Long> ids);

}
