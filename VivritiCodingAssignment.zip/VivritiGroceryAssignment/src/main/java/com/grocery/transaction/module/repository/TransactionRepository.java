package com.grocery.transaction.module.repository;

import java.io.Serializable;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.transaction.annotation.Transactional;

import com.grocery.transaction.module.model.bo.Transaction;

@Transactional
public interface TransactionRepository extends JpaRepository<Transaction, Serializable> {

}
