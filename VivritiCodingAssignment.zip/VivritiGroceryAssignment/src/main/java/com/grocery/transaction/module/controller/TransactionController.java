package com.grocery.transaction.module.controller;

import java.util.List;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;

import com.grocery.transaction.module.model.request.InventoryRequest;
import com.grocery.transaction.module.model.request.ItemRequest;
import com.grocery.transaction.module.model.request.SalesRequest;
import com.grocery.transaction.module.model.response.InventoryResponse;
import com.grocery.transaction.module.model.response.ResultResponse;
import com.grocery.transaction.module.service.core.TransactionService;

@Consumes(MediaType.APPLICATION_JSON)
@Produces(MediaType.APPLICATION_JSON)
@Path("/groceryTransaction")
public class TransactionController {

	@Autowired
	TransactionService transactionService;

	@POST
	@Path("/buyItem")
	public ResultResponse buyItem(
			@Valid @NotNull(message = "Item List can't be null") List<ItemRequest> itemRequestList)
			throws Exception {
		return transactionService.buyItem(itemRequestList);
	}

	@POST
	@Path("/printInventory")
	public List<InventoryResponse> printInventory(
			@Valid @NotNull(message = "Request List can't be null") InventoryRequest request)
			throws Exception {
		return transactionService.printInventory(request);
	}

	@POST
	@Path("/getTotalSales")
	public ResultResponse getTotalSales(
			@Valid @NotNull(message = "Request List can't be null") SalesRequest request)
			throws Exception {
		return transactionService.getTotalSales(request);
	}

	@POST
	@Path("/applyDiscountForEmployee/{empId}")
	public ResultResponse applyDiscountForEmployee(@PathVariable Long empId,
			@Valid @NotNull(message = "Item List can't be null") List<ItemRequest> itemRequestList)
			throws Exception {
		return transactionService.applyDiscountForEmployee(empId, itemRequestList);
	}

	@POST
	@Path("/applyDiscountForCustomer")
	public ResultResponse applyDiscountForCustomer(
			@Valid @NotNull(message = "Item List can't be null") List<ItemRequest> itemRequestList)
			throws Exception {
		return transactionService.applyDiscountForCustomer(itemRequestList);
	}

	
}
