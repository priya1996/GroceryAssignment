package com.grocery.transaction.module.repository;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import com.grocery.transaction.module.model.bo.DailyPurchase;

@Transactional
public interface DailyPurchaseRepository extends JpaRepository<DailyPurchase, Serializable> {
	
	@Query(" SELECT * FROM DailyPurchase WHERE itemId = :itemId ORDER BY id DESC ")
	List<DailyPurchase> findByItemId(@Param("itemId")Long itemId);
	
	@Query(" SELECT itemId FROM DailyPurchase WHERE date = :date ")
	List<Long> getDailyPurchaseByDate(@Param("date")Date date);

}
