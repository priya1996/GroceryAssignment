package com.grocery.transaction.module.model.request;

import java.util.Date;

public class ItemRequest {
	
	private Long id;
	
	private String name;
	
	private Long quantity;
	
	private Date loadInDate;
	
	private Date expiryDate;
	
	private Long producerId;
	
	private String producerName;
	
	private String producerContactNumber;
	
	private String producerAddress;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Long getQuantity() {
		return quantity;
	}

	public void setQuantity(Long quantity) {
		this.quantity = quantity;
	}

	public Date getLoadInDate() {
		return loadInDate;
	}

	public void setLoadInDate(Date loadInDate) {
		this.loadInDate = loadInDate;
	}

	public Date getExpiryDate() {
		return expiryDate;
	}

	public void setExpiryDate(Date expiryDate) {
		this.expiryDate = expiryDate;
	}

	public Long getProducerId() {
		return producerId;
	}

	public void setProducerId(Long producerId) {
		this.producerId = producerId;
	}

	public String getProducerName() {
		return producerName;
	}

	public void setProducerName(String producerName) {
		this.producerName = producerName;
	}

	public String getProducerContactNumber() {
		return producerContactNumber;
	}

	public void setProducerContactNumber(String producerContactNumber) {
		this.producerContactNumber = producerContactNumber;
	}

	public String getProducerAddress() {
		return producerAddress;
	}

	public void setProducerAddress(String producerAddress) {
		this.producerAddress = producerAddress;
	}
	
	
	
	

}
