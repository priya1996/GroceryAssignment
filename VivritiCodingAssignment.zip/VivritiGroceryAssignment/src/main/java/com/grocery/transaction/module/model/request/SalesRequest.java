package com.grocery.transaction.module.model.request;

import java.util.Date;
import java.util.List;

public class SalesRequest {
	
	private Date date;
	
	private List<Long> itemId;

	public List<Long> getItemId() {
		return itemId;
	}

	public void setItemId(List<Long> itemId) {
		this.itemId = itemId;
	}

	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}

	

}
