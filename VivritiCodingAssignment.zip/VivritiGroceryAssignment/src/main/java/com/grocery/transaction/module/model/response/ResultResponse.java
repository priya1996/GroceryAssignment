package com.grocery.transaction.module.model.response;

import java.util.List;

public class ResultResponse {
	
	private Long billId;
	
	private String code;
	
	private String msg;
	
	private List<ItemResponse> itemResponseList;
	
	private Double totalBillCost;

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getMsg() {
		return msg;
	}

	public void setMsg(String msg) {
		this.msg = msg;
	}

	public List<ItemResponse> getItemResponseList() {
		return itemResponseList;
	}

	public void setItemResponseList(List<ItemResponse> itemResponseList) {
		this.itemResponseList = itemResponseList;
	}

	public Double getTotalBillCost() {
		return totalBillCost;
	}

	public void setTotalBillCost(Double totalBillCost) {
		this.totalBillCost = totalBillCost;
	}

	public Long getBillId() {
		return billId;
	}

	public void setBillId(Long billId) {
		this.billId = billId;
	}
	
	
	

}
